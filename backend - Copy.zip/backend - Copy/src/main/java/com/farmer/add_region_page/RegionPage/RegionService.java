package com.farmer.add_region_page.RegionPage;

import com.farmer.add_region_page.VillagePage.Village;
import com.farmer.add_region_page.VillagePage.VillageRepository;
import com.farmer.exception.ErrorException;

import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RegionService {
    private final RegionRepository regionRepository;
    private final VillageRepository villageRepository;

    public RegionService(RegionRepository regionRepository,VillageRepository villageRepository){
        this.regionRepository=regionRepository;
        this.villageRepository=villageRepository;
    }   
    //POST
    public RegionDTO addRegion(RegionDTO dto){
        Village village=villageRepository.findById(dto.getVillageId()).orElseThrow(() -> new ErrorException("village not found"));
        Region region=RegionMapper.toENTITY(dto,village);
        Region savedRegion=regionRepository.save(region);
        return RegionMapper.toDTO(savedRegion);
    }
    //GET ALL
    public List<RegionDTO> getAllRegion(){
        return regionRepository.findAll().stream().map(RegionMapper::toDTO).toList();
    }

    //GET BY ID
    public RegionDTO getRegionById(Long id){
      Region region=  regionRepository.findById(id).orElseThrow(() ->new ErrorException("region not found!"));
        return RegionMapper.toDTO(region);
    }

    //DELETE
    public void deleteRegion(Long id){
        regionRepository.deleteById(id);
    }
}
