package com.farmer.add_region_page.FarmPage;
import com.farmer.add_region_page.RegionPage.Region;
import com.farmer.add_region_page.RegionPage.RegionRepository;
import com.farmer.exception.ErrorException;

import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class FarmService {
    
    private final FarmRepository farmRepository;
    private final RegionRepository regionRepository;

    public FarmService(FarmRepository farmRepository,RegionRepository regionRepository){
        this.farmRepository=farmRepository;
        this.regionRepository=regionRepository;
        
    }

    //POST FARM
    public FarmDTO addFarm(FarmDTO dto) {

        Region region = regionRepository.findById(dto.getRegionId()).orElseThrow(() -> new RuntimeException("Region not found"));

        Farm farm = FarmMapper.toENTITY(dto, region);
        return FarmMapper.toDTO(farmRepository.save(farm));
    }
    //GET FARM
    public FarmDTO getFarmById(Long id){
        Farm farm=farmRepository.findById(id).orElseThrow(()-> new ErrorException("farm not found!"));
        return FarmMapper.toDTO(farm);

    }

    //GET ALL FARM
    public List<FarmDTO> getAllFarm(){
        return farmRepository.findAll().stream().map(FarmMapper::toDTO).toList();
    }

    //delete farm
    public void deletefarm(Long id){
        farmRepository.deleteById(id);
    }
}
